#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include "Const.h"

SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;

extern void gameLoop(void);

/*!
 * Cette fonction quitte proprement la SDL 
 */
void cleanSDL()
{
	if (renderer != NULL)
		SDL_DestroyRenderer(renderer);
	if (window != NULL)
		SDL_DestroyWindow(window);
	SDL_Quit();
}

/*!
 * Cette fonction tente d'initialiser la SDL 
 * En cas d'erreur elle clean la SDL et quitte l'application avec le code EXIT_FAILURE
 */
void initSDL()
{
	if (SDL_Init(SDL_INIT_VIDEO) != 0)
	{
		cleanSDL();
		exit(EXIT_FAILURE);
	}

	window = SDL_CreateWindow("0", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
	if (window == NULL)
	{
		cleanSDL();
		exit(EXIT_FAILURE);
	}

	renderer = SDL_CreateRenderer(window, -1, 0);
	if (renderer == NULL)
	{
		cleanSDL();
		exit(EXIT_FAILURE);
	}
}

/*!
 * Bonjour madame Hoai Diem Phuc Ngo 
 * Voici le code de notre RTS ! :D
 * On a même des commentaires Doxygen parcequ'on est des oufs !
 */
int main(void)
{
	initSDL();
	gameLoop();
	cleanSDL();
	return EXIT_SUCCESS;
}
