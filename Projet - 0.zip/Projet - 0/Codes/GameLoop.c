#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include "Const.h"
#include "Map.h"
#include <SDL2/SDL_image.h>

extern SDL_Window *window;
extern SDL_Renderer *renderer;


void printMap(map gameMap) 
{
	SDL_Surface* mine = IMG_Load("../Ressources/Mine.png");
	SDL_Texture * Mine = SDL_CreateTextureFromSurface(renderer, mine);
	SDL_Color white = {35,15,50,255};
	SDL_Color black = {0,0,0,255};
	SDL_Color blue = {75,35,155,255};
	SDL_SetRenderDrawColor(renderer,blue.r,blue.g,blue.b,blue.a);
	for(int x = 0; x < ROWS_NBR; x++)
	{
		for(int y = 0; y < COLUMNS_NBR; y++)
		{
			SDL_RenderDrawLine(renderer,x*WINDOW_WIDTH/COLUMNS_NBR,0,x*WINDOW_WIDTH/COLUMNS_NBR,WINDOW_HEIGHT);
		}
		SDL_RenderDrawLine(renderer,0,x*WINDOW_HEIGHT/ROWS_NBR,WINDOW_WIDTH,x*WINDOW_HEIGHT/ROWS_NBR);
	}
	for (int x = 0; x < ROWS_NBR; x++)
	{
		for (int y = 0; y < COLUMNS_NBR; y++)
		{
			
			if(gameMap[x][y] == OCCUPIED)
			{	
				
				
				SDL_Rect currentCase;
				currentCase.x = WINDOW_WIDTH / COLUMNS_NBR * x;
				currentCase.y = WINDOW_HEIGHT / ROWS_NBR * y;
				currentCase.w = WINDOW_WIDTH / COLUMNS_NBR;
				currentCase.h = WINDOW_HEIGHT / ROWS_NBR;
				
				SDL_RenderCopy(renderer,Mine,NULL,&currentCase);
				
				
				
			}
		}
	}
	
}


void gameLoop()
{
	map gameMap = createMap();
	SDL_Event event;	
	SDL_Surface* image = SDL_LoadBMP("../Ressources/Map.BMP");
	SDL_Texture * texture = SDL_CreateTextureFromSurface(renderer, image);
	SDL_RenderCopy(renderer, texture, NULL, NULL);
	initializeMap(gameMap);

	while(1)
	{
		SDL_WaitEvent(&event);
		if(event.type == SDL_QUIT)
		{
			break;
		}
		if(event.type == SDL_MOUSEBUTTONDOWN)
		{
			int x, y;
			SDL_GetMouseState(&x, &y);
			changeCellState(gameMap, x, y);
			printf("%d %d\n", x, y);	
		}
		SDL_RenderCopy(renderer, texture, NULL, NULL);
		printMap(gameMap);
		SDL_RenderPresent(renderer);
	}
}
