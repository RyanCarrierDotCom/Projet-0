#ifndef CONST_H
#define CONST_H

#define WINDOW_HEIGHT 690
#define WINDOW_WIDTH 1488

#define COLUMNS_NBR 12
#define ROWS_NBR 12

#endif // CONST_H
