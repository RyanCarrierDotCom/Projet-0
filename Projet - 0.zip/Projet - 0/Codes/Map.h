#ifndef MAP_H
#define MAP_H

enum cell {OCCUPIED, EMPTY, FORBIDDEN};
typedef enum cell cell;
typedef cell** map;

map createMap();
void initializeMap(map gameMap);
void changeCellState(map gameMap, int x, int y);

#endif // MAP_H