#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include "Map.h"
#include "Const.h"

void initializeMap(map gameMap)
{
	for(int x = 0; x < ROWS_NBR; x++)
	{
		for(int y = 0; y < COLUMNS_NBR; y++)
		{
			gameMap[x][y] = EMPTY;
		}
	}
}

map createMap()
{
	map gameMap = (map)calloc(ROWS_NBR,sizeof(cell *));
	SDL_Event event;
	
	for(int y = 0; y < ROWS_NBR; y++)
	{
		gameMap[y] = (cell *)calloc(COLUMNS_NBR,sizeof(cell));
	}
	return gameMap;
}

void pxCoordsToMapCoords(int* x, int* y)
{
	*x = *x / (WINDOW_WIDTH / COLUMNS_NBR);
	*y = *y / (WINDOW_HEIGHT / ROWS_NBR);
}

void changeCellState(map gameMap, int x, int y)
{
	pxCoordsToMapCoords(&x, &y);
	gameMap[x][y] = OCCUPIED;
}

